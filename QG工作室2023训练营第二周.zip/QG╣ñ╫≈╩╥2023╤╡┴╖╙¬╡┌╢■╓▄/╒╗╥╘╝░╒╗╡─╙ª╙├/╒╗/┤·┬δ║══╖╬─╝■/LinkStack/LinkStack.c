#include "LinkStack.h" 
#include<stdio.h>
#include<stdlib.h>
//��ջ

//��ʼ��ջ
ElemType judje;
Status initLStack(StackNode* s) {
	s=NULL;
	return SUCCESS;
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyLStack(StackNode* s) {
	if (s == NULL) {
		judje = SUCCESS;
	}
	else {
		judje = ERROR;
	}
	return judje;
}

//�õ�ջ��Ԫ��
Status getTopLStack(StackNode* s) {
	if (s != NULL) {
		 return s->data;
	}
}

//���ջ
Status clearLStack(StackNode* s) {
	StackNode* p;
	while (s)
	{	p = s;
		s = s->next;
		free(p);
	}
	return SUCCESS;
}

//����ջ
Status destroyLStack(StackNode* s) {
	StackNode* p;
	while(s)
	{	p = s;
		s = s->next;
		free(p);
	}
	s = NULL;
	return SUCCESS;
}

//���ջ����
Status LStackLength(StackNode* s) {
	ElemType sum = 0;
	StackNode* temp = s;
	while (temp!=NULL) {
		sum++;
		temp = temp->next;
	}
	return sum;
}

//��ջ
Status pushLStack(StackNode* s, ElemType e) {
	StackNode* p = (StackNode*)malloc(sizeof(StackNode*));
	p->data = e;
	p->next = NULL;
	if (s == NULL) {
		s = p;
	}
	else {
		p->next = s;
		s = p;
	}
	return SUCCESS;
}

//��ջ
Status popLStack(StackNode* s, ElemType e) {
	StackNode* p = (StackNode*)malloc(sizeof(StackNode*));
	if (s == NULL) {
		printf("ջΪ�գ��޷���ջ");
		judje = ERROR;
	}
	else {
		p = s;
		e = p->data;
		s = s->next;
		free(p);
		printf("�ɹ���ջջ��Ԫ��");
		judje = SUCCESS;
	}
	return judje;
}
